from flask import Blueprint, request, current_app, render_template

main = Blueprint('main', __name__)

@main.route('/', methods=['GET', 'POST'])
def index():
    spec_header = current_app.config['SPEC_HEADER']
    spec_header_val = current_app.config['SPEC_HEADER_VAL']
    flag = current_app.config['FLAG']

    if request.method == "POST":
        if request.headers.get(spec_header) == spec_header_val:
            #return f"{flag}", 200
            return render_template('success.html', flag=flag), 200

    return render_template('index.html')
