import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SPEC_HEADER = os.getenv("SPEC_HEADER", "")
    SPEC_HEADER_VAL = os.getenv("SPEC_HEADER_VAL", "")
    FLAG = os.getenv("fl46")
